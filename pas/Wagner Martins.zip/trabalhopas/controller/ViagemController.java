package trabalhopas.controller;

import trabalhopas.model.*;

public class ViagemController {
    private Viagem viagem;

    public ViagemController(Onibus onibus, Motorista motorista, Rota rota, Data dataInicio) {
        this.viagem = new Viagem(onibus, motorista, rota, dataInicio);
    }



    public float calcularCusto() {
        return viagem.getCusto();
    }

    public Viagem getViagem() {
        return viagem;
    }
}
